<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
</head>
<body>
    <h1>Edit User</h1>
    <form action="{{ route('users.update', $user->id) }}" method="POST">
        @csrf
        @method('PUT')
        <p>Nama:<br><input type="text" name="name" value="{{ $user->name }}" required></p>
        <p>Email:<br><input type="email" name="email" value="{{ $user->email }}" required></p>
        <button type="submit">Update</button>
    </form>
    <p><a href="{{ route('users.index') }}">Kembali ke Daftar</a></p>
</body>
</html>
