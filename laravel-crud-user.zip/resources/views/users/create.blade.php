<!DOCTYPE html>
<html>
<head>
    <title>Tambah User</title>
</head>
<body>
    <h1>Tambah User</h1>
    <form action="{{ route('users.store') }}" method="POST">
        @csrf
        <p>Nama:<br><input type="text" name="name" required></p>
        <p>Email:<br><input type="email" name="email" required></p>
        <p>Password:<br><input type="password" name="password" required></p>
        <button type="submit">Simpan</button>
    </form>
    <p><a href="{{ route('users.index') }}">Kembali ke Daftar</a></p>
</body>
</html>
